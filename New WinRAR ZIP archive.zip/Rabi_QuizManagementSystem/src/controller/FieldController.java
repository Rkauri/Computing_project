/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import rabi_classes.Field;

/**
 *
 * @author Rkauri
 */
public class FieldController {
   public void insertField(Field f){
        String sql1="SELECT * FROM `field` WHERE `fieldname`='"+f.getField()+"'";
       // System.out.println(sql1);
   boolean has=false;
   String field=null;
        Statement st=Dbconnector.getConnect();
     try {
           ResultSet rs=st.executeQuery(sql1);
           while(rs.next()){
               field=rs.getString(2);
               if(field!=null){
           has=true;
           }
           }
       } catch (Exception e) {
           System.out.println("field select vayena");
       }
        if(has==false){
        String sql= "INSERT INTO `field`(`fieldname`) VALUES ('"+f.getField()+"')";
  
       try {
           st.executeUpdate(sql);
       } catch (Exception e) {
           System.out.println("field insert vayena");
       }
        }
   } 
   public int getFieldId(String field){
   int id=0;
  
       String sql="SELECT `fieldid` FROM `field` WHERE fieldname='"+field+"'";
   Statement st=Dbconnector.getConnect();
       try {
           ResultSet rs=st.executeQuery(sql);
           while(rs.next()){
           id=rs.getInt(1);
           }
       } catch (Exception e) {
           System.out.println("field id select vayena");
       }
   return id;
   }
   public ArrayList<Field> getFieldDetail(){
   ArrayList<Field> af = new ArrayList<>();
   String sql="SELECT * FROM `field`";
   Statement st=Dbconnector.getConnect();
       try {
           ResultSet rs=st.executeQuery(sql);
           while(rs.next()){
           Field f = new  Field();
            f.setField(rs.getString(2));
// System.out.println(f.getField());
              af.add(f);
           }
       } catch (Exception e) {
           System.out.println("field ko arry aayena");
       }
           return af;
   
   }
}
