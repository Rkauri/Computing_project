/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import rabi_classes.Player;
import rabi_classes.Question;

/**
 *
 * @author Rkauri
 */
public class InsertQuestion {
public int getAnswerId(){
String sql="select Max(answerid) from answer";
int id=0;
Statement st=Dbconnector.getConnect();
    try {
        ResultSet rs=st.executeQuery(sql);
        rs.next();
         id=rs.getInt(1);
        id=id+1;
    } catch (Exception e) {
    }
return id;
}
    public void setQuestion(Question q) {
        String sql = "INSERT INTO `question`(`question`, `answerid`, `correctanswer`, `levelid`, `fieldid`) VALUES ('" + q.getQuestion() + "'," + q.getAnswerid() + ",'" + q.getCorrectanswer() + "'," + q.getLevelid() + "," + q.getFieldid() + ")";
        System.out.println(sql);
        Statement st = Dbconnector.getConnect();
        try {
            st.executeUpdate(sql);
        } catch (Exception e) {
            System.out.println("question insertion failed");
        }
    }

    public Question getQuestion(int id) {
      //  ArrayList<Question> aq = new ArrayList<>();
      Question qu= new Question() ;
        String sql = "SELECT * FROM `question` where questionid="+id;
        Statement st = Dbconnector.getConnect();
        try {
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                qu.setQuestion_id(rs.getInt(1));
                qu.setQuestion(rs.getString(2));
                qu.setAnswerid(rs.getInt(3));
                qu.setCorrectanswer(rs.getString(4));
                qu.setLevelid(rs.getInt(5));
                qu.setFieldid(rs.getInt(6));
               // aq.add(qu);
            }
        } catch (Exception e) {
            System.out.println("cannot gat data from question table");
        }
        return qu;
    }
     public ArrayList<Question>  getQuestion(int fieldid,int difficulty) {
        ArrayList<Question> aq = new ArrayList<>();
     // Question qu= new Question() 
        String sql = "SELECT * FROM `question` where fieldid='"+fieldid+"' and levelid='"+difficulty+"'";
        Statement st = Dbconnector.getConnect();
        try {
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
              Question qu= new Question() ;
                qu.setQuestion_id(rs.getInt(1));
                qu.setQuestion(rs.getString(2));
                qu.setAnswerid(rs.getInt(3));
//                qu.setCorrectanswer(rs.getString(4));
//                System.out.println(rs.getString(2));
//                System.out.println(rs.getString(4));
//                System.out.println(rs.getInt(3));
//qu.setLevel(rs.getInt(5));
                //qu.setField(rs.getString(6));
           
                // aq.add(qu);
                aq.add(qu);
            }
        } catch (Exception e) {
            System.out.println("cannot gat data from question table");
        }
        return aq;
    }
   
    public int countQuestion(int id,int field, int level) {
         int a=0;
        String sql = "SELECT count(questionid) as count FROM `question` WHERE fieldid='"+field+"' and levelid='"+level+"' " ;
        System.out.println(sql);
        Statement st = Dbconnector.getConnect();
        try {
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
            a=rs.getInt("count");
            }
               // aq.add(qu);
            
        } catch (Exception e) {
            System.out.println("cannot gat data from question table");
        }
        return a;
    }
   
}
