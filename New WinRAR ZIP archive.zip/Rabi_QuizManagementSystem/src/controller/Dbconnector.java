/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Rkauri
 */
public class Dbconnector {
    public static Statement getConnect(){
     try{
            Class.forName("com.mysql.jdbc.Driver");
        
       }catch(Exception e){
           System.out.println("drever loaded");
       }
       Connection con=null;
       try{
           con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz","root","");
       }catch(Exception e){
           System.out.println("connection not made");
       }
       Statement st=null;
       try{
         st= con.createStatement();
     
         
       }catch(Exception e){
           System.out.println("final kaam vayena");
       }    
       
    
    return st;
    }
}
