/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import rabi_classes.Answer;

/**
 *
 * @author Rkauri
 */
public class AddAnswer {

    public void setAnswer(Answer a) {
        String sql = "INSERT INTO `answer`(`optionfirst`, `optionsecond`, `optionthird`, `optionfourth`) VALUES ('" + a.getOptionfirst() + "','" + a.getOptionsecond() + "','" + a.getOptionthird() + "','" + a.getOptionfourth() + "')";
        Statement st = Dbconnector.getConnect();
        try {
            st.executeUpdate(sql);
        } catch (Exception e) {
            System.out.println("answer insertion failed");
        }
    }

    public Answer getAnswer(int answerid) {
        Answer aa = new Answer();
        String sql = "SELECT * FROM `answer` where answerid=" + answerid;
        Statement st = Dbconnector.getConnect();
        try {
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                //Answer aa= new Answer(
                aa.setAnswerid(rs.getInt(1));
                aa.setOptionfirst(rs.getString(2));
                aa.setOptionsecond(rs.getString(3));
                aa.setOptionthird(rs.getString(4));
                aa.setOptionfourth(rs.getString(5));

            }
        } catch (Exception e) {
            System.out.println("cannot get data from answer table");
        }
        return aa;
    }
    public ArrayList getAnswerList(int answerid) {
        ArrayList al= new ArrayList<>();
        
        String sql = "SELECT * FROM `answer` where answerid=" + answerid;
        Statement st = Dbconnector.getConnect();
        try {
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
               
                //al.add(rs.getInt(1));
                al.add(rs.getString(2));
                al.add(rs.getString(3));
                al.add(rs.getString(4));
                al.add(rs.getString(5));
                
            }
        } catch (Exception e) {
            System.out.println("cannot get data from answer table");
        }
        return al;
    }

    public int checkAnswer(String answer, int questionid) {
        int a = 0;
        String correctanswer = null;
        String sql = "SELECT `correctanswer` FROM `question` WHERE questionid=" + questionid;
        Statement st = Dbconnector.getConnect();
        try {
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                correctanswer = rs.getString(1);
                if (correctanswer.equals(answer)) {
                    a = 1;
                }

            }
        } catch (Exception e) {
            System.out.println("correct answer check garna milena");
        }

        return a;
    }
    public int getScore(int a)
    {
          
          a++;
    return a;
    }
}
