
import controller.FieldController;
import java.util.ArrayList;
import rabi_classes.Field;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rkauri
 */
public class cleckArrayList {
    public static void main(String[] args) {
        FieldController fc= new FieldController();
                
        ArrayList<Field> af= fc.getFieldDetail();
        for(Field f:af){
            System.out.println(f.getField());
        }
    }
 
}
