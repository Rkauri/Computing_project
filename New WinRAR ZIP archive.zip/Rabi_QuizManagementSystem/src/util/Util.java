/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Rkauri
 */
public class Util {

    public static int initialcount, finalcount=0;
    public static int score;

    public static int changeDifficulty(int a) {
        initialcount = a;
        if(initialcount>finalcount){
        finalcount=initialcount;
        }
        int level = 0;
        if (finalcount == 0) {
            level = 1;
        } else if (finalcount == 1) {
            level = 2;
        } else if (finalcount >= 2) {
            level = 3;
        }
        return level;
    }

    public int getSocre() {
        score++;
        return score;
    }
}
