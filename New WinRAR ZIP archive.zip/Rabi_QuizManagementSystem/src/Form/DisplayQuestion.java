/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Form;

import controller.AddAnswer;
import controller.FieldController;
import controller.InsertQuestion;
import java.awt.List;
import java.util.ArrayList;
import java.util.Random;
import rabi_classes.Answer;
import rabi_classes.Question;
import util.Util;

/**
 *
 * @author Rkauri
 */
public class DisplayQuestion extends javax.swing.JPanel {

    int questionid = 0, answerid = 0;
    public static int count = 1, counter = 0, check = 0, j = 0;
    public static int nums = 0;
    public static int level, fieldid;
    public static String field;
    public static String aaa[];

    /**
     * Creates new form DisplayQuestion
     */
    public DisplayQuestion(String field, int difficulty) {
        initComponents();
        nums = 0;//variable for increasing score
        count = 1;// variable for counting the no of displayed question 
        j = 0; //variable for looping question
        this.field = field; //variable for question field
        this.level = difficulty; //variable for difficulty level
       
        aaa = new String[4]; //array for storing answer
        jButton3.setVisible(false);
        if (count == 1) {  //condition for showing button
            jButton2.setVisible(false);
        } else {
            jButton2.setVisible(true);
        }
        FieldController fc = new FieldController();
        fieldid = fc.getFieldId(field); //selection of field id from field table by field name
        InsertQuestion iq = new InsertQuestion();
        counter = iq.countQuestion(count, fieldid, level);  //method counting total questions from question table same field id and difficulty level and storing into a variable 
       
        if (counter >= count) {  //condition to check no of question available 
            ArrayList<Question> alq = iq.getQuestion(fieldid, level); //arraylist to store questions of same field id and difficulty level
            try {
                if (j < alq.size()) { //condition to loop until the length of arraylist 
                  
                    questionid = alq.get(j).getQuestion_id();
                    jLabel1.setText(alq.get(j).getQuestion());
                    answerid = alq.get(j).getAnswerid();
                    j++;
                } else {

                    System.out.println("out of bound");
                }
            } catch (Exception e) {
                System.out.println("error aayo^");
            }
            Answer a = new Answer();
            AddAnswer aa = new AddAnswer();
            ArrayList aq = aa.getAnswerList(answerid);  //method to get answer from answer table with the answerid
            ArrayList<Integer> ai = new ArrayList<>(); //arraylist to generate numbers from 1-4 so that radom rumbers  can be generated from 1-4 without repetation
            for (int i = 1; i < 5; i++) {
                ai.add(i);
            }
            Random rand = new Random();

            while (aq.size() > 0) { // generating random number from 1-4 using this condition
                int index = rand.nextInt(aq.size());
                String item = (String) aq.get(index);
                int num = ai.get(index);
               

                aaa[nums] = (String) aq.remove(index);  //storing answer located at index and storing it to array of index nums
                if (nums == 0) {//setting value at radio button from array 
                    jRadioButton1.setText(aaa[0]);

                    jRadioButton1.setActionCommand(aaa[0]);
                }
                if (nums == 1) {
                    jRadioButton2.setText(aaa[1]);

                    jRadioButton2.setActionCommand(aaa[1]);
                }

                if (nums == 2) {
                    jRadioButton3.setText(aaa[2]);

                    jRadioButton3.setActionCommand(aaa[2]);
                }

                if (nums == 3) {
                    jRadioButton4.setText(aaa[3]);

                    jRadioButton4.setActionCommand(aaa[3]);
                }
                nums++;
            }

        } else {//displaying total score after the game finish
            jLabel1.setText( "Your total score: ");
            jRadioButton1.setVisible(false);
            jRadioButton2.setVisible(false);
            jRadioButton3.setVisible(false);
            jRadioButton4.setVisible(false);
            jButton3.setVisible(true);
            jButton1.setVisible(false);
            jButton2.setVisible(false);
        }
    }

    public void getDisplay() { //method to call in every action of jButton1 (Next)
        aaa[0] = "";
        aaa[1] = "";
        aaa[2] = "";
        aaa[3] = "";
        nums = 0;
        jButton3.setVisible(false);
        if (count == 1) {
            jButton2.setVisible(false);
        } else {
            jButton2.setVisible(true);
        }
        InsertQuestion iq = new InsertQuestion();
        counter = iq.countQuestion(count, fieldid, level);
        if (counter >= count) {
            ArrayList<Question> alq = iq.getQuestion(fieldid, level);
            try {
                if (j < alq.size()) {
                    System.out.println(j);
                    questionid = alq.get(j).getQuestion_id();
                    jLabel1.setText(alq.get(j).getQuestion());
                    answerid = alq.get(j).getAnswerid();
                    j++;
                }
            } catch (Exception e) {
                System.out.println("error aayo^");
            }
            Answer a = new Answer();
            AddAnswer aa = new AddAnswer();
            ArrayList aq = aa.getAnswerList(answerid);
            ArrayList<Integer> ai = new ArrayList<>();
            for (int i = 1; i < 5; i++) {
                ai.add(i);
            }
            Random rand = new Random();

            while (aq.size() > 0) {
                int index = rand.nextInt(aq.size());
                String item = (String) aq.get(index);
                int num = ai.get(index);

                aaa[nums] = (String) aq.remove(index);
                if (nums == 0) {
                    jRadioButton1.setText(aaa[0]);

                    jRadioButton1.setActionCommand(aaa[0]);
                }
                if (nums == 1) {
                    jRadioButton2.setText(aaa[1]);

                    jRadioButton2.setActionCommand(aaa[1]);
                }

                if (nums == 2) {
                    jRadioButton3.setText(aaa[2]);

                    jRadioButton3.setActionCommand(aaa[2]);
                }

                if (nums == 3) {
                    jRadioButton4.setText(aaa[3]);

                    jRadioButton4.setActionCommand(aaa[3]);
                }
                nums++;
            }
            aaa[0] = null;
            aaa[1] = null;
            aaa[2] = null;
            aaa[3] = null;

            //}
        } else {
            jLabel1.setText("Game over" + "\n" + "your total score:" + check);
            jRadioButton1.setVisible(false);
            jRadioButton2.setVisible(false);
            jRadioButton3.setVisible(false);
            jRadioButton4.setVisible(false);
            jButton3.setVisible(true);
            jButton1.setVisible(false);
            jButton2.setVisible(false);

        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(550, 550));

        jPanel1.setPreferredSize(new java.awt.Dimension(650, 650));

        jLabel1.setFont(new java.awt.Font("Lucida Sans", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Lucida Sans", 0, 18)); // NOI18N
        jRadioButton1.setActionCommand("1");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Lucida Sans", 0, 18)); // NOI18N
        jRadioButton2.setActionCommand("2");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton3);
        jRadioButton3.setFont(new java.awt.Font("Lucida Sans", 0, 18)); // NOI18N
        jRadioButton3.setActionCommand("3");
        jRadioButton3.setAutoscrolls(true);
        jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton3ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton4);
        jRadioButton4.setFont(new java.awt.Font("Lucida Sans", 0, 18)); // NOI18N
        jRadioButton4.setActionCommand("4");
        jRadioButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 513, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jRadioButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jRadioButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(85, 85, 85)
                        .addComponent(jRadioButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(146, 146, 146))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(jRadioButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(jRadioButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton4)))
                .addContainerGap(78, Short.MAX_VALUE))
        );

        jButton1.setText("Next");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Previous");

        jButton3.setText("Restart");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jButton1)
                        .addGap(28, 28, 28)
                        .addComponent(jButton3)
                        .addGap(42, 42, 42)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addContainerGap(161, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton3ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        count++;//increment of value  

        String opt = buttonGroup1.getSelection().getActionCommand();//get value from selected radio button
        AddAnswer aa = new AddAnswer();
        if (aa.checkAnswer(opt, questionid) == 1) { //check if the answer is true or false
            //Util.changeDifficulty(check);
            check++;
        } else {
            //Util.changeDifficulty(aa.checkAnswer(opt, questionid));
        }

        this.getDisplay();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        nums = 0;
        count = 1;
        j = 0;
        jRadioButton1.setVisible(true);
        jRadioButton2.setVisible(true);
        jRadioButton3.setVisible(true);
        jRadioButton4.setVisible(true);
        jButton1.setVisible(true);
        jButton2.setVisible(true);
        this.getDisplay();
    }//GEN-LAST:event_jButton3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    // End of variables declaration//GEN-END:variables
}
