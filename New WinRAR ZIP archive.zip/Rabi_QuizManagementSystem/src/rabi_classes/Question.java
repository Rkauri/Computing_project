/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package rabi_classes;

/**
 *
 * @author Rkauri
 */
public class Question {
    private int question_id;
    private String question;
    private int answerid;
    private String correctanswer;
    private int levelid;
    private int fieldid;

    public Question() {
    }

    public Question(int question_id, String question, int answerid, String correctanswer, int levelid, int fieldid) {
        this.question_id = question_id;
        this.question = question;
        this.answerid = answerid;
        this.correctanswer = correctanswer;
        this.levelid = levelid;
        this.fieldid = fieldid;
    }

    public int getQuestion_id() {
        return question_id;
    }

    public void setQuestion_id(int question_id) {
        this.question_id = question_id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public int getAnswerid() {
        return answerid;
    }

    public void setAnswerid(int answerid) {
        this.answerid = answerid;
    }

    public String getCorrectanswer() {
        return correctanswer;
    }

    public void setCorrectanswer(String correctanswer) {
        this.correctanswer = correctanswer;
    }

    public int getLevelid() {
        return levelid;
    }

    public void setLevelid(int levelid) {
        this.levelid = levelid;
    }

    public int getFieldid() {
        return fieldid;
    }

    public void setFieldid(int fieldid) {
        this.fieldid = fieldid;
    }

}
