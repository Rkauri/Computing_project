/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package rabi_classes;

/**
 *
 * @author Rkauri
 */
public class Field {
    private int fieldid;
    private String field;

    public Field() {
    }

    public Field(int fieldid, String field) {
        this.fieldid = fieldid;
        this.field = field;
    }

    public int getFieldid() {
        return fieldid;
    }

    public void setFieldid(int fieldid) {
        this.fieldid = fieldid;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }
    
}
