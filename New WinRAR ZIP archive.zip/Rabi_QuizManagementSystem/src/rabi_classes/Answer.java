/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package rabi_classes;

/**
 *
 * @author Rkauri
 */
public class Answer {
    private int answerid;
    private String optionfirst;
    private String optionsecond;
    private String optionthird;
    private String optionfourth;

    public Answer() {
    }

    public Answer(int answerid, String optionfirst, String optionsecond, String optionthird, String optionfourth) {
        this.answerid = answerid;
        this.optionfirst = optionfirst;
        this.optionsecond = optionsecond;
        this.optionthird = optionthird;
        this.optionfourth = optionfourth;
    }

    public int getAnswerid() {
        return answerid;
    }

    public void setAnswerid(int answerid) {
        this.answerid = answerid;
    }

    public String getOptionfirst() {
        return optionfirst;
    }

    public void setOptionfirst(String optionfirst) {
        this.optionfirst = optionfirst;
    }

    public String getOptionsecond() {
        return optionsecond;
    }

    public void setOptionsecond(String optionsecond) {
        this.optionsecond = optionsecond;
    }

    public String getOptionthird() {
        return optionthird;
    }

    public void setOptionthird(String optionthird) {
        this.optionthird = optionthird;
    }

    public String getOptionfourth() {
        return optionfourth;
    }

    public void setOptionfourth(String optionfourth) {
        this.optionfourth = optionfourth;
    }
    
}
