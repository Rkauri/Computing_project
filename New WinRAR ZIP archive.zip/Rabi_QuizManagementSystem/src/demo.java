
import controller.InsertQuestion;
import java.util.ArrayList;
import rabi_classes.Question;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rkauri
 */
public class demo {
    public static void main(String[] args) {
        InsertQuestion iq = new InsertQuestion();
        ArrayList<Question> alq=iq.getQuestion(1, 1);
        System.out.println(alq.size());
        try {
            for(int i=0; i<alq.size(); i++){
            System.out.println(alq.get(i).getQuestion());
            System.out.println(alq.get(i).getCorrectanswer());
        }  
        } catch (Exception e) {
            System.out.println("error aayo^");
        }
       
    }
 
}
